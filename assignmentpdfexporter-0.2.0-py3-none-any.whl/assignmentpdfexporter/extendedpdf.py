"""Modified Export to PDF via latex"""
import os
from nbconvert.exporters.pdf import PDFExporter

from traitlets import Unicode, default

class ExtendedPDFExporter(PDFExporter):

    @property
    def template_paths(self, prune=True, root_dirs=None):
        return super()._template_paths()+[os.path.join(os.path.dirname(__file__), "templates", "customlatex")]
    
    def _template_file_default(self):
        """
        We want to use the new template we ship with our library.
        """
        return 'myindex.tex.j2'
    
    markdown_font = Unicode("default", help="Font for the Markdown cells").tag(config=True)
    code_font     = Unicode("default", help="Font for the Code cells").tag(config=True)
    author_name   = Unicode("", help="Name of the Author").tag(config=True)
    author_div    = Unicode("", help="Division of the Author").tag(config=True)
    author_rollno = Unicode("", help="Roll No of the Author").tag(config=True)

    output_mimetype = "application/pdf"
    def from_notebook_node(self, nb, resources=None, **kw):
        resources["global_font_filter"] = {
            "markdown_font": self.markdown_font,
            "code_font": self.code_font
        }
        resources["global_author_details"] = {
            "author_name": self.author_name,
            "author_div": self.author_div,
            "author_rollno": self.author_rollno
        }
        return super().from_notebook_node(nb, resources, **kw)

    